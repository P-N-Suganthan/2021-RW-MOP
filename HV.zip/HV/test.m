clc;
clear all;
load('Pop.mat');
HV_Score = HV(Pop,1)